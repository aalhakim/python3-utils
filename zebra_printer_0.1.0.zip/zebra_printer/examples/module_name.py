
MODULE_NAME = "zebra-printer"